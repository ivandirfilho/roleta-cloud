"""Test for BUG-011: Validate spin direction with minimal dependencies."""
import sys
import os
from pathlib import Path
from unittest.mock import MagicMock

# Ensure project root is in path
sys.path.insert(0, os.getcwd())

# 1. Setup minimal mocks to allow importing GameState
mock_pydantic = MagicMock()
mock_pydantic_settings = MagicMock()
sys.modules["pydantic"] = mock_pydantic
sys.modules["pydantic_settings"] = mock_pydantic_settings

class MockBaseSettings:
    def __init__(self, **kwargs): pass
mock_pydantic_settings.BaseSettings = MockBaseSettings
mock_pydantic_settings.SettingsConfigDict = MagicMock
mock_pydantic.BaseModel = MagicMock
mock_pydantic.Field = MagicMock

mock_settings = MagicMock()
mock_settings.game.max_timeline_size = 45
mock_settings.game.sda_forces_analyzed = 4
mock_settings.state_file = Path("state.json")

mock_settings_module = MagicMock()
mock_settings_module.settings = mock_settings
sys.modules["app_config.settings"] = mock_settings_module

# 2. Now import GameState
from state.game import GameState

def test_process_spin_validates_direction():
    """Verify that process_spin only accepts 'horario' and 'anti-horario'."""
    gs = GameState()
    
    # Valid directions should work (if last_direction is empty, returns 0 but updates state)
    assert gs.process_spin(17, "horario") == 0
    assert gs.last_number == 17
    assert gs.last_direction == "horario"
    
    # Mock _calculate_force to avoid roulette dependencies if any
    gs._calculate_force = MagicMock(return_value=10)
    
    # Valid direction with previous spin
    force = gs.process_spin(32, "anti-horario")
    assert force == 10
    assert gs.last_number == 32
    assert gs.last_direction == "anti-horario"
    
    # Invalid directions should be ignored and return 0
    gs.last_number = 32
    gs.last_direction = "anti-horario"
    
    assert gs.process_spin(15, "invalid") == 0
    assert gs.last_number == 32 # Should not have updated
    assert gs.last_direction == "anti-horario"
    
    assert gs.process_spin(15, "cw") == 0
    assert gs.last_number == 32
    assert gs.last_direction == "anti-horario"
    
    assert gs.process_spin(15, "ccw") == 0
    assert gs.last_number == 32
    assert gs.last_direction == "anti-horario"
    
    assert gs.process_spin(15, None) == 0
    assert gs.last_number == 32
    assert gs.last_direction == "anti-horario"

    assert gs.process_spin(15, 123) == 0
    assert gs.last_number == 32
    assert gs.last_direction == "anti-horario"

if __name__ == "__main__":
    try:
        test_process_spin_validates_direction()
        print("Test passed!")
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
